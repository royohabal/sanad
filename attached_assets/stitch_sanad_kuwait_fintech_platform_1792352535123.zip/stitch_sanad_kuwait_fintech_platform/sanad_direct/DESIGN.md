---
name: Sanad Direct
colors:
  surface: '#fff8f3'
  surface-dim: '#e5d8c9'
  surface-bright: '#fff8f3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff2e1'
  surface-container: '#f9ecdc'
  surface-container-high: '#f3e6d6'
  surface-container-highest: '#ede1d1'
  on-surface: '#211b11'
  on-surface-variant: '#534345'
  inverse-surface: '#362f25'
  inverse-on-surface: '#fcefdf'
  outline: '#857275'
  outline-variant: '#d8c1c3'
  surface-tint: '#904857'
  primary: '#3d0617'
  on-primary: '#ffffff'
  primary-container: '#581c2b'
  on-primary-container: '#d58191'
  inverse-primary: '#ffb2bf'
  secondary: '#9d4226'
  on-secondary: '#ffffff'
  secondary-container: '#fe8c6a'
  on-secondary-container: '#74240a'
  tertiary: '#33111a'
  on-tertiary: '#ffffff'
  tertiary-container: '#4c252e'
  on-tertiary-container: '#c18a95'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffd9de'
  primary-fixed-dim: '#ffb2bf'
  on-primary-fixed: '#3c0616'
  on-primary-fixed-variant: '#733140'
  secondary-fixed: '#ffdbd1'
  secondary-fixed-dim: '#ffb59f'
  on-secondary-fixed: '#3a0a00'
  on-secondary-fixed-variant: '#7e2b11'
  tertiary-fixed: '#ffd9df'
  tertiary-fixed-dim: '#f3b7c2'
  on-tertiary-fixed: '#321019'
  on-tertiary-fixed-variant: '#653a44'
  background: '#fff8f3'
  on-background: '#211b11'
  surface-variant: '#ede1d1'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
  currency-display:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.03em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.25rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

This design system establishes a warm, community-centered, and distinctly Kuwaiti financial lifestyle experience. It balances modern digital finance utility with the cultural resonance of everyday generosity: peer micro-tipping (valet, baristas, service staff), parent-to-child digital allowances, and celebratory gifting such as Eidiyah and Girgian. 

The aesthetic is built on approachable tactile organicism: smooth pill contours, warm creamy card stocks, deep burgundy foundations, and vibrant desert-coral accents. The UI eschews cold, sterile enterprise banking tropes in favor of a hospitable, human-first feel that respects privacy while making every interaction feel like a gracious handover of goodwill.

## Colors

The palette draws inspiration from Kuwait's cultural warmth, desert tones, and regional hospitality traditions:

- **Primary (`#581C2B`)**: Deep Burgundy anchors the brand header, dominant navigation bars, core statements, and high-impact structural frames.
- **Secondary (`#EF805F`)**: Warm Coral functions as the active state engine—driving calls-to-action, dynamic tip selections, celebratory animations, and active savings progress.
- **Tertiary (`#3B1720`)**: Dark Wine serves as high-contrast body text, dense numerical values (KWD currency readouts), and active pressed-state surfaces.
- **Neutral Base (`#F5E8D8`)**: Warm Cream provides the soft, anti-glare canvas across mobile screen viewports.
- **Surface Elevation (`#FAF4EC` & `#FFFFFF`)**: Used for tactile payment sheets, worker profile cards, and modal sheets.
- **Dividers & Strokes (`#E8DAC8` / `rgba(88, 28, 43, 0.10)`)**: Soft hairline separation ensuring clean containment without visual clutter.
- **Status Accents**:
  - Success: Forest Green (`#2E7D32`) on Soft Jade tint (`#E8F5E9`) for confirmed payouts and completed transfers.
  - Pending: Amber Ember (`#F57C00`) on Warm Honey tint (`#FFF3E0`) for unsettled bills and queued gifts.

## Typography

Typographic scale is optimized for high legibility on handheld devices, featuring tight numerical layouts tailored for KWD currency values and seamless RTL (Arabic) / LTR (English) alignment.

- **Plus Jakarta Sans** delivers friendly, open geometry with rounded terminal points that mirror the organic pill surfaces of the UI.
- All monetary figures employ tabular numerical alignment when displayed inside transaction logs, tip calculators, and Eidiyah goal ledgers.
- Currency denominations prioritize clarity: 3-decimal places for standard dinar amounts (e.g., `1.250 KWD` or `د.ك 1.250`) and direct colloquial counts for sub-dinar tokens (e.g., `250 fils`, `500 fils`).
- Arabic and English pairing maintains vertical optical balance across toggles and status indicators without vertical drift.

## Layout & Spacing

The layout is built mobile-first, targeting single-thumb reach zones for micro-payments, tipping cards, and scan interactions:

- **Grid Model**: A fluid 4-column layout on mobile (`< 600px`) transitioning into an 8-column layout on tablet/desktop viewports.
- **Rhythm & Touch Targets**: Interactive targets maintain a minimum vertical height of `48px` with `space-sm` (`8px`) minimum separation.
- **Margins & Safe Zones**: Mobile viewports utilize an edge margin of `16px` (`margin-mobile`), ensuring full immersion while preventing accidental thumb triggers near hardware bezels. Floating bottom sheets and action bars feature elevated safe-bottom padding (`space-xl` to `space-2xl`).
- **Reflow**: Bidirectional mirror logic is built into all flex and grid containers to accommodate RTL flows natively without shifting visual weights.

## Elevation & Depth

Depth is established via warm, low-opacity ambient shadows tinted by the primary burgundy tone, creating an organic layered paper feel rather than stark artificial drop shadows:

- **Level 0 (Flat Ground)**: Base background `#F5E8D8`. No shadow.
- **Level 1 (Card & Section Containers)**: `#FFFFFF` or `#FAF4EC` surfaces resting on `box-shadow: 0 4px 16px -2px rgba(88, 28, 43, 0.06), 0 1px 3px 0 rgba(88, 28, 43, 0.04)`. Outlined with a hairline border `1px solid rgba(88, 28, 43, 0.08)`.
- **Level 2 (Interactive Floating Modules & Modals)**: Bottom sheets, QR scan modals, and worker tipping profiles: `box-shadow: 0 12px 32px -4px rgba(88, 28, 43, 0.12), 0 4px 12px -2px rgba(88, 28, 43, 0.06)`.
- **Level 3 (Floating Action Pills & Keypads)**: Quick action send/tip triggers: `box-shadow: 0 16px 36px -6px rgba(239, 128, 95, 0.35)`.
- **Subtle Cultural Ornamentation**: Select elevated sheets can display watermark-level geometric Sadu/Islamic patterns rendered at `3%` opacity (`rgba(88, 28, 43, 0.03)`), providing cultural texture without compromising legibility.

## Shapes

The interface embraces a hyper-approachable pill and capsule philosophy (Level 3 roundedness). Sharp corners are eliminated to evoke safety, friendliness, and tactile ease:

- **Buttons & Input Badges**: Full stadium pills (`border-radius: 9999px` / `rounded-full`).
- **Standard Cards & Profile Panels**: `border-radius: 2rem` (`rounded-lg`).
- **Modal Drawers & Eidiyah Gift Envelopes**: `border-radius: 3rem` (`rounded-xl`) on exposed corners.
- **Micro-Chips & Transaction Tags**: Pill contours (`border-radius: 9999px`) maintaining uniform radius regardless of width.

## Components

### Buttons & Quick Actions
- **Primary Action**: Full pill shape with Deep Burgundy (`#581C2B`) background, `#FAF4EC` label text, and `52px` standard mobile height. Hover/active states blend toward Dark Wine (`#3B1720`).
- **Accent Action (Tip / Send)**: Warm Coral (`#EF805F`) with pure white or deep wine text, accompanied by dynamic haptic feedback.
- **Secondary / Ghost Pill**: Transparent fill with `1.5px` border in `#581C2B1A` and Deep Burgundy text.

### Preset Tip & Gift Chips
- Horizontal scrolling rows of capsule buttons for rapid selection: `250 fils`, `500 fils`, `1.000 KWD`, `2.000 KWD`, and `Custom`.
- **Unselected**: `#FAF4EC` background, subtle `#E8DAC8` border, `#3B1720` typography.
- **Selected**: Warm Coral (`#EF805F`) solid fill with white bold typography and soft coral glow.

### Worker & Recipient Hero Profile Cards
- Elevated `#FFFFFF` card with `rounded-2xl` geometry.
- Centered circular avatar with double border ring (`#EF805F`).
- Bilingual name display (English and Arabic script), localized service badge (e.g., "Barista", "Valet Captain"), and total direct tips received counter.

### Transaction Timeline Badges
- **Completed**: `#E8F5E9` background with `#2E7D32` typography and small pill checkmark icon.
- **Pending**: `#FFF3E0` background with `#F57C00` typography and soft pulsing indicator dot.
- **Processing**: Soft Burgundy tint (`rgba(88, 28, 43, 0.08)`) with `#581C2B` label.

### Gamified Savings & Eidiyah Goal Bars
- Container track in `#E8DAC8` with `rounded-full` height of `12px`.
- Active progress indicator rendered in Warm Coral (`#EF805F`) with animated shimmer highlights upon reaching milestone tiers (e.g., `75% of Eidiyah Target`).

### Input Fields & Keypads
- Large tactile amount input field with central alignment, large Plus Jakarta Sans currency numbers, dynamic "KWD / د.ك" switcher tag, and zero harsh outlines. Focus state activates a `2px` Warm Coral soft border.